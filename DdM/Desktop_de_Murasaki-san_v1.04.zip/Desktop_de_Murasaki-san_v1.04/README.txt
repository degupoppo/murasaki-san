
# Desktop de Murasaki-san

Version: 1.04
Release Date: 2023/07/26


## Overview

This program provides Murasaki-san as a desktop mascot on your PC. By using this program, you can constantly monitor parameters of House of Murasaki-san on your desktop. This program is a part of the Murasaki-san Project (https://murasaki-san.com/).

This program only calls information from the blockchain and does not send any transactions. Your wallet address or secret key is not required, and please do not input them.


## Installation

To install this software, please follow these steps:

1. Download the software from https://murasaki-san.com/.
2. Extract the software to a directory of your choice.
3. Replace the value of "Murasaki-san_ID" in the "Desktop_de_Murasaki-san.ini" with your Murasaki-san ID.
4. Run the "Desktop_de_Murasaki-san.exe" file.


## Usage

Murasaki-san and the information window will appear on the bottom left of your desktop. Murasaki-san on your desktop reflects the on-chain parameters and changes its behavior accordingly.

When you move your mouse cursor near Murasaki-san, it runs away so that it does not interfere with your PC work :)

The information window will displays Murasaki-san's current satiety, happy, working status (mining, farming, crafting, strolling, practicing), and several alert icons (dice roll, cat-mail, level-up, gingerbread house, present box). The information window can be moved by drag and drop.

The Astar information window will displays the current price of $ASTR and the price change percentage in 1 hr, 24 hr, and 7 days. The weather icon changes depending on the $ASTR price. The price informations is powered by the CoinGecko API (https://www.coingecko.com/en/api).

By right-clicking the task tray icon and selecting from the menu, you can manage the display/hide settings of the information window and adjust the height of Murasaki-san. To exit the program, right-click the task tray icon and select "Exit".

By editing the "Desktop_de_Murasaki-san.ini" file, you can configure the following settings:
 - Murasaki-san_ID:  your Murasaki-san ID
 - height_adjustment:  Y-axis position of Murasaki-san (default: -96)
 - mouse_distance:  distance to detect the mouse cursor (default: 100)
 - enable_mouse_escape:  whether to enable escaping from mouse cursor (default: 1)
 - display_number:  PC monitor number to retrieve resolution (default: 0)
 - show_window_info:  Show (1) or hide (0) Murasaki-san information window (default: 1)
 - show_window_astar:  Show (1) or hide (0) Astar information window (default: 1)
 - window_opacity:  opacity of the information window (default: 90)
 - astar_endpoint_url:  Astar network RPC address (default: https://evm.astar.network)
 - address_murasaki_info:  contract address to call on-chain parameters (default: 0x8909C388868F42b8E517B5A615F2845080a69ac9)


## License

This software is licensed under MIT.


## Copyright

Copyright (C) 2023 degupoppo & fumacist


## Changelog

* 1.04 - 2023/07/26
    * The weather icon feature has been added to the Astar information window.

* 1.03 - 2023/07/25
    * The Astar information window feature has been added.
    * The show/hide settings for each info window have been added to the ini file.
    * Minor bug fixes.

* 1.02 - 2023/07/24
    * Minor bug fixes.

* 1.01 - 2023/07/21
    * Minor bug fixes.

* 1.00 - 2023/07/20
    * Initial release.

* 0.01 - 2023/07/12
    * Alpha release.
